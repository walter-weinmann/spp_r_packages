spp_test <- "../database/spp_test.db"

# ==============================================================================

test_that("distr_year.df(): eod - content & structure test", {
  result <- sppr::distr_year.df(sppr::eod_raw.df(spp_test))

  expect_equal(class(result),
               "data.frame")
  expect_equal(dim(result),
               c(14,
                 4))
  expect_equal(c(names(result)),
               c("symbol",
                 "name",
                 "first_day",
                 "last_day"))
})

