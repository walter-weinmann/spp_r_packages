library(testthat)
library(sppr)

test_check("sppr")
